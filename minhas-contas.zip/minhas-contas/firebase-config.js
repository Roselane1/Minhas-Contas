// Cole aqui a configuração do seu projeto Firebase
// (Console do Firebase > Configurações do projeto > Seus apps > App da Web > Configuração do SDK).
// Enquanto ficar vazio, o app funciona salvando os dados só no aparelho.
window.FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
